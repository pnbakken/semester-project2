export default function clearElement(element) {
    element.innerHTML = "";
}