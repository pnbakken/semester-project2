export default function newProduct() {
    const form = document.querySelector("#product-form");
    form.addEventListener("submit", (event) => {
        event.preventDefault();
        
    })
}